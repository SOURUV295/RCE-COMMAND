# Vulnerability Title

> Vulnerability description - reference

## Summary

* [Tools](#tools)
* [Methodology](#methodology)
    * [Subentry 1](#subentry-1)
    * [Subentry 2](#subentry-2)
* [Labs](#labs)
* [References](#references)

## Tools

* [username/tool1](https://github.com/username/tool1) - Description of the tool
* [username/tool2](https://github.com/username/tool2) - Description of the tool

## Methodology

Quick explanation

```powershell
Exploit
```

### Subentry 1

### Subentry 2

## Labs

* [Root Me - Lab 1](https://root-me.org)
* [PortSwigger - Lab 2](https://portswigger.net)
* [HackTheBox - Lab 3](https://www.hackthebox.com)

## References

* [Blog title - Author (@handle) - Month XX, 202X](https://example.com)
